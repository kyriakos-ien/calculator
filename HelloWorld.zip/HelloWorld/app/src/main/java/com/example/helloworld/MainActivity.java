package com.example.helloworld;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.NumberKeyListener;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.nio.file.Files;


public class MainActivity extends AppCompatActivity {
    private Button number0;
    private Button number1;
    private Button number2;
    private Button number3;
    private Button number4;
    private Button number5;
    private Button number6;
    private Button number7;
    private Button number8;
    private Button number9;
    private Button addition;
    private Button subtraction;
    private Button multiplication;
    private Button division;
    private Button equals;
    private Button point;
    private OnClickListener numberKeyListener;
    private String stored_num;
    private String stored_num2;
    private boolean isStored = false;
    private boolean operatorActivated;
    private int int_stored_num;
    private int int_stored_num2;

    public void numberKeyPressed(String number){

        EditText calcScreen = (EditText)findViewById(R.id.calcScreen);
        calcScreen = (EditText)findViewById(R.id.calcScreen);
        String string_screen= calcScreen.getText().toString();
        int start = calcScreen.getSelectionStart();

        if (string_screen.length()>0){
            Log.v("debug", "test1");
            String first = string_screen.substring(0,start);
            String second = string_screen.substring(start,string_screen.length());
            Log.v("debug", first);
            Log.v("debug", second);
            calcScreen.setText(first + number + second );
            calcScreen.setSelection(start+1);
            if (operatorActivated == true){
                calcScreen.getText().clear();
                calcScreen.setText(number);
                calcScreen.setSelection(1);
                isStored = true;
                operatorActivated = false;
            }
        }else if(!number.equalsIgnoreCase("0")){
            calcScreen.setText(number);
            calcScreen.setSelection(1);
            Log.v("debug", "test2");
        }



    }

    public void operatorPressed(char operator){
        TextView resultScreen = (TextView)findViewById(R.id.resultScreen);
        EditText calcScreen = (EditText)findViewById(R.id.calcScreen);


        if (isStored == true){
            stored_num2 = String.valueOf(calcScreen.getText());
            int int_stored_num2 = Integer.parseInt(stored_num2);
            int int_result = int_stored_num + int_stored_num2;
            Log.v("second", stored_num2);
            Log.v("res", String.valueOf(int_result));
            String result = Integer.toString(int_result);
            calcScreen.setText(result);
            isStored = false;


        }else{
            stored_num = String.valueOf(calcScreen.getText());
            Log.v("first", stored_num);
            int_stored_num = Integer.parseInt(stored_num);


        }
        operatorActivated = true;


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numberKeyListener = new  View.OnClickListener() {
            public void onClick(View v) {
                numberKeyPressed((String) v.getTag());

            }
        };
        number0 = (Button) findViewById(R.id.btn0);
        number1 = (Button) findViewById(R.id.btn1);
        number2 = (Button) findViewById(R.id.btn2);
        number3 = (Button) findViewById(R.id.btn3);
        number4 = (Button) findViewById(R.id.btn4);
        number5 = (Button) findViewById(R.id.btn5);
        number6 = (Button) findViewById(R.id.btn6);
        number7 = (Button) findViewById(R.id.btn7);
        number8 = (Button) findViewById(R.id.btn8);
        number9 = (Button) findViewById(R.id.btn9);
        addition = (Button)findViewById(R.id.btn_addition);
        subtraction = (Button) findViewById(R.id.btn_subtraction);
        multiplication = (Button) findViewById(R.id.btn_multiplication);
        division = (Button) findViewById(R.id.btn_division);
        equals = (Button) findViewById(R.id.btn_equals);
        point = (Button) findViewById(R.id.btn_point);

        final EditText calcScreen = (EditText)findViewById(R.id.calcScreen);
        final TextView resultScreen = (TextView)findViewById(R.id.resultScreen);
        calcScreen.setShowSoftInputOnFocus(false);


        number0.setTag("0");
        number0.setOnClickListener(numberKeyListener);

        number1.setTag("1");
        number1.setOnClickListener(numberKeyListener);

        number2.setTag("2");
        number2.setOnClickListener(numberKeyListener);

        number3.setTag("3");
        number3.setOnClickListener(numberKeyListener);

        number4.setTag("4");
        number4.setOnClickListener(numberKeyListener);

        number5.setTag("5");
        number5.setOnClickListener(numberKeyListener);

        number6.setTag("6");
        number6.setOnClickListener(numberKeyListener);

        number7.setTag("7");
        number7.setOnClickListener(numberKeyListener);

        number8.setTag("8");
        number8.setOnClickListener(numberKeyListener);

        number9.setTag("9");
        number9.setOnClickListener(numberKeyListener);

        /* MY CODE
        number4.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                numberKeyPressed("4");
            }
        });
        number5.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                numberKeyPressed("5");
            }
        });
        number6.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                numberKeyPressed("6")
            }
        });
        number7.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                numberKeyPressed("7");
            }
        });
        number8.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                numberKeyPressed("8");
            }
        });
        number9.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                numberKeyPressed("9");
            }
        });
        */
        //Operators
        addition.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                operatorPressed('+');

            }
        });
        calcScreen.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                calcScreen.getSelectionStart();


            }
        });





    }
}
